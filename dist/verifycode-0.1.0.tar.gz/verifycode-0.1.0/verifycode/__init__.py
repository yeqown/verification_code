VERSION = '0.1.0'
AUTHOR = 'yeqown'
REPO_URL = 'https://github.com/yeqown/verification_code'